package vcmsa.ci.mealchoices

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val mealSuggestion = findViewById<TextView>(R.id.mealSuggestion)
        val edtMealPeriod = findViewById<EditText>(R.id.edtMealPeriod) // Input for meal period
        val btnReset = findViewById<Button>(R.id.btnReset)
        val btnShowSuggestion = findViewById<Button>(R.id.btnShowSuggestion)
        val textView = findViewById<TextView>(R.id.textView)

        btnShowSuggestion.setOnClickListener {
            val mealPeriod = edtMealPeriod.text.toString().trim().lowercase() // Get user input and convert to lowercase
            val suggestion = getMealSuggestion(mealPeriod)
            if (suggestion != null) {
                mealSuggestion.text = suggestion
            } else {
                handleInputError(mealPeriod)
            }
        }
   // IIE Module Manual(2025)
        btnReset.setOnClickListener {
            edtMealPeriod.text.clear() // Clear the input field
            mealSuggestion.text = "" // Clear the suggestion text
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun getMealSuggestion(mealPeriod: String): String? {                // IIE Module Manual(2025)
        return when (mealPeriod) {
            "morning" -> "Meal Suggestions for Morning: Oatmeal, Fruit Salad, Smoothie"
            "mid-morning" -> "Meal Suggestions for Mid-morning: Yogurt, Granola Bar, Nuts"
            "afternoon" -> "Meal Suggestions for Afternoon: Sandwich, Salad, Pasta"
            "mid-afternoon" -> "Meal Suggestions for Mid-afternoon: Cheese and Crackers, Veggies and Hummus, Fruit"
            "dinner" -> "Meal Suggestions for Dinner: Steak, Stir-fry, Tacos"
            else -> null // Return null for invalid meal period
        }
    }
    // IIE Module Manual(2025)
    private fun handleInputError(input: String) {
        when {
            input.isEmpty() -> {
                Toast.makeText(this, "Please enter a meal period (e.g., morning).", Toast.LENGTH_SHORT).show()
            }
            !listOf("morning", "mid-morning", "afternoon", "mid-afternoon", "dinner").contains(input) -> {
                Toast.makeText(this, "Invalid meal period. Please enter one of the following: morning, mid-morning, afternoon, mid-afternoon, dinner.", Toast.LENGTH_SHORT).show()
            }
            else -> {
                Toast.makeText(this, "Unexpected error. Please try again.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

// REFERENCE LIST :
// IIE Module Manual(2025).Independent Institution Of Education (Accessed: 31 March 2025).
// Stack Overflow. (2025).Stack Overflow. Available at: https://stackoverflow.com/questions (Accessed: 31 March 2025).





